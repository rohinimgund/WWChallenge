package pageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import utility.testBase;

public class wwStudioFinderPage {
	
	public static String wwStudioFinderPageTitle() {
		return testBase.getDriver().getTitle();
	}

	public static WebElement finderButton(String finder) {
		if(finder.equals("Studio")) {
			return testBase.getDriver().findElements(By.className("buttonWrapper-QK2gi")).get(1);
		}
		else {
			return testBase.getDriver().findElements(By.className("buttonWrapper-QK2gi")).get(0);
		}

	}
	
	public static WebElement locationSearchInput() {
		return testBase.getDriver().findElement(By.id("location-search"));
	}
	
	public static WebElement locationSearchSubmitButton() {
		return testBase.getDriver().findElement(By.id("location-search-cta"));
	}
	
}
