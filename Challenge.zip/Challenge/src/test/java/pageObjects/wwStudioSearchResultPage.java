package pageObjects;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import utility.testBase;

public class wwStudioSearchResultPage {

	public static List<List<WebElement>> searchResults() {
		List<List<WebElement>> searchResults = new ArrayList<List<WebElement>>();
		List<WebElement> titleList = searchResultTitles();
		List<WebElement> distanceList = searchResultDistances();
		searchResults.add(titleList);
		searchResults.add(distanceList);
		return searchResults;
	}
	
	public static List<WebElement> searchResultTitles(){
		return testBase.getDriver().findElements(By.className("linkUnderline-1_h4g"));
	}
	
	public static List<WebElement> searchResultDistances(){
		return testBase.getDriver().findElements(By.className("distance-OhP63"));
	}
}
