package pageObjects;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import utility.testBase;

public class wwStudioSingleSearchResultDetailsPage {
	
	public static WebElement studioLocationName() {
		return testBase.getDriver().findElement(By.className("locationName-1jro_"));
	}

	public static WebElement businessHoursLinkForStudioLocation() {
		return testBase.getDriver().findElement(By.className("hours-IVyrp"));
	}
	
	public static void printAllBusinessHoursForStudioLocation() {
		List<WebElement> dayList = testBase.getDriver().findElements(By.className("dayName-CTNC6"));
		List<WebElement> timeList = testBase.getDriver().findElements(By.className("times-fms3v"));
		for(int index=0;index<dayList.size();index++) {
			System.out.println(dayList.get(index).getText()+" "+getBusinessHours(timeList.get(index)));
		}
	}
	
	public static String getBusinessHours(WebElement element) {
		StringBuilder businessHoursForDay=new StringBuilder();
		if(element.getText().contains("\n")) {
			String[] stringArray = element.getText().split("\n");
			for(String string:stringArray) {
				businessHoursForDay.append(string);
				businessHoursForDay.append("   ");
			}
			return businessHoursForDay.toString();
		}
		else {
			return element.getText();
		}
		
		
	}
}
