package Challenge.Challenge;

import org.junit.Assert;
import org.junit.Test;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import pageObjects.wwStudioFinderPage;
import pageObjects.wwStudioSearchResultPage;
import pageObjects.wwStudioSingleSearchResultDetailsPage;
import utility.testBase;

public class takeHomeUIAutomationTest{
	
	@Test
	public void testWWStudioFinderPageScenario() {
		// Build expected title for the WW Find Workshop Page
		Character ch = '|';
		StringBuilder expectedTitleSB = new StringBuilder();
		expectedTitleSB.append("Find WW Studios & Meetings Near You ");
		expectedTitleSB.append(ch);
		expectedTitleSB.append(" WW USA");
		String expectedTitle = expectedTitleSB.toString();
		
		// Navigate to WW Studio Finder page
		testBase.visitPage("https://www.weightwatchers.com/us/find-a-workshop/");
		
		// Assert loaded page title contains “Find WW Studios & Meetings Near You | WW USA”
		Assert.assertEquals(expectedTitle,wwStudioFinderPage.wwStudioFinderPageTitle());

		// Under Find your Workshop, click on Studios
		wwStudioFinderPage.finderButton("Studio").click();
		
		// Assert loaded page contains location search field
		Assert.assertTrue(wwStudioFinderPage.locationSearchInput().isDisplayed());
		
		// Clear location search input field 
		wwStudioFinderPage.locationSearchInput().clear();
		
		// In the search field, search for meetings for zip code: 10011
		wwStudioFinderPage.locationSearchInput().sendKeys("10011");
		wwStudioFinderPage.locationSearchSubmitButton().click();
		
		
		WebDriverWait wait = new WebDriverWait(testBase.getDriver(),30);		
		String firstSearchResultTitle,firstSearchResultDistance="";
		
		try {
			
			// Assert loaded Page contains relative search results
			Assert.assertFalse(wwStudioSearchResultPage.searchResults().isEmpty());
			firstSearchResultTitle = wwStudioSearchResultPage.searchResults().get(0).get(0).getText();
			firstSearchResultDistance = wwStudioSearchResultPage.searchResults().get(1).get(0).getText();
		}
		catch(StaleElementReferenceException e) {
			
			// Explicitly wait till first search result is visible
			wait.until(ExpectedConditions.visibilityOf(wwStudioSearchResultPage.searchResults().get(0).get(0)));
			firstSearchResultTitle = wwStudioSearchResultPage.searchResults().get(0).get(0).getText();
			firstSearchResultDistance = wwStudioSearchResultPage.searchResults().get(1).get(0).getText();
		}	
		
		// Print the title of the first result and the distance (located on the right of location title/name)
		System.out.println("The title of the first result = " + firstSearchResultTitle);
		System.out.println("Distance for first location result = " + firstSearchResultDistance);
		
		// Click on the first search result 
		wwStudioSearchResultPage.searchResultTitles().get(0).click();
		
		// Verify displayed location name/title matches with the name of the first searched result that was clicked.
		Assert.assertEquals(firstSearchResultTitle, wwStudioSingleSearchResultDetailsPage.studioLocationName().getText());
		
		// Click on Business Hours
		wwStudioSingleSearchResultDetailsPage.businessHoursLinkForStudioLocation().click();
		
		// Print all the business hours for that studio
		System.out.println("Business Hours:");
		wwStudioSingleSearchResultDetailsPage.printAllBusinessHoursForStudioLocation();
		
		// Close browser opened during test
		testBase.quit();
	}
	
	
	
	

}
